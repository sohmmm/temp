import streamlit as st
from langchain.text_splitter import RecursiveCharacterTextSplitter
import requests
from prompt_maker import  get_prompt, get_categories
from convert_excel import convert_excel
from langchain.document_loaders import TextLoader
import os
from git import Repo
from Api import analyze_code
import shutil
import stat

st.write("Download the test template for the reference:")
template_path = r"Code_quality_prompts.xlsx"
download_button = st.download_button(label="Download", data=open(template_path, 'rb'),file_name="Example_TestTemplate.xlsx", mime='application/vnd.ms-excel',key="Examples", help='The sheet consist of different test examples for the various categories of tests.')
excel_path = st.file_uploader('Test Excel file', type=['xlsx','xls'] )
repo_path = st.text_input('Code repo path', '')
selected_language = st.selectbox('Language:',
                      ('.java', '.py', '.cpp'))

local_path = r"Repository"


def delete_repo(local_path):
    for root, dirs, files in os.walk(local_path, topdown=False):
        for name in files:
            filename = os.path.join(root, name)
            os.chmod(filename, stat.S_IWUSR) # add permission to delete
            os.remove(filename)
        # for name in dirs:
        #     os.rmdir(os.path.join(root, name))
    
    # Now, you should be able to delete the root directory
    os.rmdir(local_path)
    print(f"Local copy at {local_path} deleted")

def handle_submit():  
    delete_repo(local_path)
    repo = Repo.clone_from(repo_path, local_path)    
    categories = get_categories(excel_path)
    file1 = open("report.txt","a")
    texts= None
    try:
        for category in categories:
            prompt= get_prompt(excel_path, category)
            code_list=[]
            for path, _, files in os.walk(local_path):
                for filename in files:
                    if filename.endswith(str(selected_language)):
                        print(filename)
                        file_path = os.path.join(path, filename)
                        loader = TextLoader(file_path)
                        documents = loader.load()
                        text_splitter = RecursiveCharacterTextSplitter(
                            chunk_size = 40000,
                            chunk_overlap  = 8000,
                            length_function = len
                            )

                        texts = text_splitter.split_documents(documents)
                
                        for code in texts:
                            code_list.append(str(code))


            assistant_response = analyze_code(category,prompt,code_list)
            st.write(assistant_response)
            file1.write(assistant_response)
            print("Code quality analysis in progress")
    except Exception as e:
        print(e)

        
    file1.close()
    convert_excel()
    #download_excel = download_excel(label="Download report", data=open('output.xlsx', 'rb'),file_name="output.xlsx", mime='application/vnd.ms-excel')
    print("\n\n---Code quality analysis done---")
    delete_repo(local_path)
    

if st.button("Submit"):
    handle_submit()

    

#efficient code of twosum

    



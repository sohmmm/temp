import time
import os
import stat
from git import Repo
 
# Clone repository
repo_url = "https://github.com/Kalebu/Website-blocker-python.git"
local_path = r"C:/Solution/Repository"
 
# Change permissions and delete
for root, dirs, files in os.walk(local_path, topdown=False):
    for name in files:
        filename = os.path.join(root, name)
        os.chmod(filename, stat.S_IWUSR) # add permission to delete
        os.remove(filename)
    for name in dirs:
        os.rmdir(os.path.join(root, name))
 
# Now, you should be able to delete the root directory
os.rmdir(local_path)
print(f"Local copy at {local_path} deleted")
 
Repo.clone_from(repo_url, local_path)
print(f"Repository cloned to {local_path}")
 
# Add a delay
time.sleep(5)
 
# Change permissions and delete
for root, dirs, files in os.walk(local_path, topdown=False):
    for name in files:
        filename = os.path.join(root, name)
        os.chmod(filename, stat.S_IWUSR) # add permission to delete
        os.remove(filename)
    for name in dirs:
        os.rmdir(os.path.join(root, name))
 
# Now, you should be able to delete the root directory
os.rmdir(local_path)
print(f"Local copy at {local_path} deleted")
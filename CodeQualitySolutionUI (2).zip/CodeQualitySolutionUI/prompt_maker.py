import pandas as pd
import openpyxl

def get_prompt(path, category):
    # Load the Excel file
    workbook = openpyxl.load_workbook(path)

    sheet = workbook[category]
    column_values = []
    # for cell in sheet['B']:
    #     column_values.append(cell.value)

    for cell in sheet['A']:
            if str(cell.value) != 'None':
                column_values.append(cell.value)
    prompt = " \n".join(column_values[1:])
    start = """
            Display "All good" with the file name and the category if there are no improvements suggested.
            Generate a file wise table only if improvements are suggested.
            The table should strictly contain 4 columns- File name, line number, Improvement suggested, code snippet that needs to be changed. 
            The file name column will have the file name in which changes are suggested.
            The line number column will have the line number of the code snippet.
            The improvement suggested column will have the changes suggested based on the testing aspects.
            The code snippet column will have code snippet where the changes are to be done.
            The category of test must be mentioned above the table.
            The report must fit in page, there should be no need to scroll horizotally, vertical scrolling is okay.
            Reduce the font size if needed.      
            
            Nothing else than this table should be there in the output.
            Please stick to the above aspects only. 
             """ 
    
    return start+category+"The testing aspects are as follows."+prompt

def get_categories(file_path):
    columns_to_read=['Category','Selection']
    sheet_name='Categories'
    df = pd.read_excel(file_path,sheet_name=sheet_name,usecols=columns_to_read, engine="openpyxl")
    categories=df[df['Selection']=='Yes']
    return categories['Category'].to_list()



    
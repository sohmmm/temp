import openai
def analyze_code(category,prompt,code_list):
    assistant_response=""
    openai.api_type = "azure"
    openai.api_base = "https://enggexopenai.openai.azure.com/"
    openai.api_version = "2023-07-01-preview"
    openai.api_key = ""
    system_prompt="""
                        You are a code quality expert. You'll analyze the quality of the code on the given parameters.
                        Display "All good" with file name and the category if there are no improvements suggested.
                        Generate a file wise tables only if improvements are suggested.
                        The table should compulsary have the 4 columns in order - File name, line number ,improvement suggested, the code snippet that needs to changed.
                        The report must fit in page, there should be no need to scroll horizotally, vertical scrolling is okay.
                        Reduce the font size if needed. Category type should be mentioned above the table. 
                        Strictly generate the table with  above mentioned 4 columns.   
                    """
    for code in code_list:
        prompt = prompt+"The category of the test is"+category+" The part of code for the file is as follows: \n" + str(code)
        print("Sending request for summary to Azure OpenAI endpoint...\n\n")
        response = openai.ChatCompletion.create(
        engine="EnggExGPT35",
        temperature=0.0,
        # max_tokens=120,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": prompt}
        ]
        )
        assistant_response = response['choices'][0]['message']['content']
    return assistant_response
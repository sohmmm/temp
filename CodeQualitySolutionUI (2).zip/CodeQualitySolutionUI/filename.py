import os
repo_path = r"C://Users//vishakha_dhumal//OneDrive - Persistent Systems Limited//Desktop//Python-Projects-master//Supervised Learning"
for path, _, files in os.walk(repo_path):
            for filename in files:
                    if filename.endswith(".py"):
                        print(filename)
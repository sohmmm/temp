import pandas as pd
import re


def convert_excel():
    # Provided text
    f = open("report.txt", "r")
    text = f.read()
    text.encode('unicode_escape')
    
    
    # Regular expression to find strings with three pipes
    pattern = re.compile(r'\|[^|]+\|[^|]+\|[^|]+\|[^|]+\|')
    
    # Find all occurrences of strings with three pipes
    matches = re.findall(pattern, text)

    # Extracting headers and rows
    headers = [header.strip() for header in matches[0].split('|') if header.strip()]
    rows=[]
    for i in range(1,len(matches)):
        rows.append([row.strip() for row in matches[i].split('|') if row.strip()])
        
    
    # Create a DataFrame
    df = pd.DataFrame(rows, columns=headers)
    
    # # Display the DataFrame
    df.to_excel('output.xlsx', index=False)
    print("Excel report generated")

